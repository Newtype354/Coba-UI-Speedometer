package com.mycompany.project;

import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class ui{

    @FXML
    private ProgressBar speedBar; // ProgressBar untuk kecepatan
    @FXML
    private ProgressBar rpmBar; // ProgressBar untuk RPM
    
    @FXML
    private Text speedText; // Text untuk menampilkan nilai kecepatan
    @FXML
    private Text rpmText; // Text untuk menampilkan nilai RPM
    @FXML
    private Text tempText; // Text untuk menampilkan temperatur
    @FXML
    private TextField speedInput; // Input untuk kecepatan
    @FXML
    private TextField rpmInput; // Input untuk RPM
    @FXML
    private TextField tempInput; // Input untuk temperatur

    private double currentSpeed = 0.0; // Kecepatan saat ini
    private double currentRPM = 0.0; // RPM saat ini
    private double currentTemp = 0.0; // Temperatur saat ini

    // Method untuk mengatur kecepatan
    @FXML
    public void setSpeed() {
        try {
            currentSpeed = Double.parseDouble(speedInput.getText());
            updateSpeedometer();
        } catch (NumberFormatException e) {
            speedText.setText("Invalid Input"); // Tampilkan pesan jika input tidak valid
        }
    }

    // Method untuk mengatur RPM
    @FXML
    public void setRPM() {
        try {
            currentRPM = Double.parseDouble(rpmInput.getText());
            updateRPM();
        } catch (NumberFormatException e) {
            rpmText.setText("Invalid Input"); // Tampilkan pesan jika input tidak valid
        }
    }

    // Method untuk mengatur temperatur
    @FXML
    public void setTemperature() {
        try {
            currentTemp = Double.parseDouble(tempInput.getText());
            updateTemperature();
        } catch (NumberFormatException e) {
            tempText.setText("Invalid Input"); // Tampilkan pesan jika input tidak valid
        }
    }

    // Method untuk memperbarui tampilan speedometer
    private void updateSpeedometer() {
        speedBar.setProgress(currentSpeed / 100.0); // Asumsi kecepatan maksimum 100
        speedText.setText(String.format("%.2f km/h", currentSpeed));
        updateSpeedColor();
    }

    // Method untuk memperbarui tampilan RPM
    private void updateRPM() {
        rpmBar.setProgress(currentRPM / 10000.0); // Asumsi RPM maksimum 10000
        rpmText.setText(String.format("%.2f RPM", currentRPM));
        updateRPMColor();
    }

    // Method untuk memperbarui tampilan temperatur
    private void updateTemperature() {
        //tempBar.setProgress(currentTemp / 100.0); // Asumsi temperatur maksimum 100 derajat
        tempText.setText(String.format("%.2f °C", currentTemp));
        //updateTempColor();
    }

    // Method untuk mengubah warna bar berdasarkan kecepatan
    private void updateSpeedColor() {
        if (currentSpeed < 50) {
            speedBar.setStyle("-fx-accent: green;"); // Warna hijau untuk kecepatan normal
        } else if (currentSpeed < 80) {
            speedBar.setStyle("-fx-accent: yellow;"); // Warna kuning untuk peringatan
        } else {
            speedBar.setStyle("-fx-accent: red;"); // Warna merah untuk bahaya
        }
    }

    // Method untuk mengubah warna bar berdasarkan RPM
    private void updateRPMColor() {
        if (currentRPM < 3000) {
            rpmBar.setStyle("-fx-accent: green;"); // Warna hijau untuk RPM normal
        } else if (currentRPM < 6000) {
            rpmBar.setStyle("-fx-accent: yellow;"); // Warna kuning untuk peringatan
        } else {
            rpmBar.setStyle("-fx-accent: red;"); // Warna merah untuk bahaya
        }
    }

    // Method untuk mengubah warna bar berdasarkan temperatur
   
}
