package com.mycompany.project;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Memuat file FXML
        Parent root = FXMLLoader.load(getClass().getResource("/com/mycompany/project/ui.fxml"));
        
        // Mengatur judul jendela
        primaryStage.setTitle("Speedometer Application");
        
        // Mengatur scene dengan ukuran yang sesuai
        primaryStage.setScene(new Scene(root, 600, 300));
        
        // Menampilkan jendela
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args); // Meluncurkan aplikasi
    }
}
